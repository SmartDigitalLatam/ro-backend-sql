export interface SessionContext {
    resourceId?: string;
    resourceAddress?: string;
    resourceType?: string;
    isNameBased?: boolean;
    operationType?: string;
}
