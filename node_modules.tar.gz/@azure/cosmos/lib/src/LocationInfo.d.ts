/**
 * Used to store the location info in Location Cache
 * @private
 * @hidden
 */
export declare class LocationInfo {
    preferredLocations: ReadonlyArray<string>;
    availableReadEndpointByLocation: ReadonlyMap<string, string>;
    availableWriteEndpointByLocation: ReadonlyMap<string, string>;
    orderedWriteLocations: ReadonlyArray<string>;
    orderedReadLocations: ReadonlyArray<string>;
    writeEndpoints: ReadonlyArray<string>;
    readEndpoints: ReadonlyArray<string>;
    constructor(other: LocationInfo);
    constructor(preferredLocations: ReadonlyArray<string>, defaultEndpoint: string);
}
