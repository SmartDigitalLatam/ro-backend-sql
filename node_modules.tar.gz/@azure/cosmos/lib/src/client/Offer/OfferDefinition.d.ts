export interface OfferDefinition {
    id?: string;
    offerType?: string;
    offerVersion?: string;
    resource?: string;
    offerResourceId?: string;
    content?: {
        offerThroughput: number;
        offerIsRUPerMinuteThroughputEnabled: boolean;
    };
}
