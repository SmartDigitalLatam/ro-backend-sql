export interface DatabaseDefinition {
    /** The id of the database. */
    id?: string;
}
