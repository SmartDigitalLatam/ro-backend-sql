import { ChangeFeedIterator } from "../../ChangeFeedIterator";
import { ChangeFeedOptions } from "../../ChangeFeedOptions";
import { ClientContext } from "../../ClientContext";
import { SqlQuerySpec } from "../../queryExecutionContext";
import { QueryIterator } from "../../queryIterator";
import { FeedOptions, RequestOptions } from "../../request";
import { Container } from "../Container";
import { ItemDefinition } from "./ItemDefinition";
import { ItemResponse } from "./ItemResponse";
/**
 * Operations for creating new items, and reading/querying all items
 *
 * @see {@link Item} for reading, replacing, or deleting an existing container; use `.item(id)`.
 */
export declare class Items {
    readonly container: Container;
    private readonly clientContext;
    /**
     * Create an instance of {@link Items} linked to the parent {@link Container}.
     * @param container The parent container.
     * @hidden
     */
    constructor(container: Container, clientContext: ClientContext);
    /**
     * Queries all items.
     * @param query Query configuration for the operation. See {@link SqlQuerySpec} for more info on how to configure a query.
     * @param options Used for modifying the request (for instance, specifying the partition key).
     * @example Read all items to array.
     * ```typescript
     * const querySpec: SqlQuerySpec = {
     *   query: "SELECT * FROM Families f WHERE f.lastName = @lastName",
     *   parameters: [
     *     {name: "@lastName", value: "Hendricks"}
     *   ]
     * };
     * const {result: items} = await items.query(querySpec).toArray();
     * ```
     */
    query(query: string | SqlQuerySpec, options?: FeedOptions): QueryIterator<any>;
    /**
     * Queries all items.
     * @param query Query configuration for the operation. See {@link SqlQuerySpec} for more info on how to configure a query.
     * @param options Used for modifying the request (for instance, specifying the partition key).
     * @example Read all items to array.
     * ```typescript
     * const querySpec: SqlQuerySpec = {
     *   query: "SELECT firstname FROM Families f WHERE f.lastName = @lastName",
     *   parameters: [
     *     {name: "@lastName", value: "Hendricks"}
     *   ]
     * };
     * const {result: items} = await items.query<{firstName: string}>(querySpec).toArray();
     * ```
     */
    query<T>(query: string | SqlQuerySpec, options?: FeedOptions): QueryIterator<T>;
    /**
     * Create a `ChangeFeedIterator` to iterate over pages of changes
     *
     * @param partitionKey
     * @param changeFeedOptions
     *
     * @example Read from the beginning of the change feed.
     * ```javascript
     * const iterator = items.readChangeFeed({ startFromBeginning: true });
     * const firstPage = await iterator.executeNext();
     * const firstPageResults = firstPage.result
     * const secondPage = await iterator.executeNext();
     * ```
     */
    readChangeFeed(partitionKey: string | number | boolean, changeFeedOptions: ChangeFeedOptions): ChangeFeedIterator<any>;
    /**
     * Create a `ChangeFeedIterator` to iterate over pages of changes
     *
     * @param changeFeedOptions
     */
    readChangeFeed(changeFeedOptions?: ChangeFeedOptions): ChangeFeedIterator<any>;
    /**
     * Create a `ChangeFeedIterator` to iterate over pages of changes
     *
     * @param partitionKey
     * @param changeFeedOptions
     */
    readChangeFeed<T>(partitionKey: string | number | boolean, changeFeedOptions: ChangeFeedOptions): ChangeFeedIterator<T>;
    /**
     * Create a `ChangeFeedIterator` to iterate over pages of changes
     *
     * @param changeFeedOptions
     */
    readChangeFeed<T>(changeFeedOptions?: ChangeFeedOptions): ChangeFeedIterator<T>;
    /**
     * Read all items.
     *
     * There is no set schema for JSON items. They may contain any number of custom properties.
     *
     * @param options Used for modifying the request (for instance, specifying the partition key).
     * @example Read all items to array.
     * ```typescript
     * const {body: containerList} = await items.readAll().toArray();
     * ```
     */
    readAll(options?: FeedOptions): QueryIterator<ItemDefinition>;
    /**
     * Read all items.
     *
     * Any provided type, T, is not necessarily enforced by the SDK.
     * You may get more or less properties and it's up to your logic to enforce it.
     *
     * There is no set schema for JSON items. They may contain any number of custom properties.
     *
     * @param options Used for modifying the request (for instance, specifying the partition key).
     * @example Read all items to array.
     * ```typescript
     * const {body: containerList} = await items.readAll().toArray();
     * ```
     */
    readAll<T extends ItemDefinition>(options?: FeedOptions): QueryIterator<T>;
    /**
     * Create a item.
     *
     * There is no set schema for JSON items. They may contain any number of custom properties..
     *
     * @param body Represents the body of the item. Can contain any number of user defined properties.
     * @param options Used for modifying the request (for instance, specifying the partition key).
     */
    create(body: any, options?: RequestOptions): Promise<ItemResponse<ItemDefinition>>;
    /**
     * Create a item.
     *
     * Any provided type, T, is not necessarily enforced by the SDK.
     * You may get more or less properties and it's up to your logic to enforce it.
     *
     * There is no set schema for JSON items. They may contain any number of custom properties.
     *
     * @param body Represents the body of the item. Can contain any number of user defined properties.
     * @param options Used for modifying the request (for instance, specifying the partition key).
     */
    create<T extends ItemDefinition>(body: T, options?: RequestOptions): Promise<ItemResponse<T>>;
    /**
     * Upsert an item.
     *
     * There is no set schema for JSON items. They may contain any number of custom properties.
     *
     * @param body Represents the body of the item. Can contain any number of user defined properties.
     * @param options Used for modifying the request (for instance, specifying the partition key).
     */
    upsert(body: any, options?: RequestOptions): Promise<ItemResponse<ItemDefinition>>;
    /**
     * Upsert an item.
     *
     * Any provided type, T, is not necessarily enforced by the SDK.
     * You may get more or less properties and it's up to your logic to enforce it.
     *
     * There is no set schema for JSON items. They may contain any number of custom properties.
     *
     * @param body Represents the body of the item. Can contain any number of user defined properties.
     * @param options Used for modifying the request (for instance, specifying the partition key).
     */
    upsert<T extends ItemDefinition>(body: T, options?: RequestOptions): Promise<ItemResponse<T>>;
}
