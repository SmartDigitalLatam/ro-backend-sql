export declare enum ConflictResolutionMode {
    Custom = "Custom",
    LastWriterWins = "LastWriterWins"
}
