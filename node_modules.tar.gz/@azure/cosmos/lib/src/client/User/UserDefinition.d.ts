export interface UserDefinition {
    /** The id of the user. */
    id?: string;
}
