import { RequestOptions } from ".";
import { CosmosClient } from "./CosmosClient";
import { CosmosClientOptions } from "./CosmosClientOptions";
import { DatabaseAccount } from "./documents";
import { CosmosResponse } from "./request";
import { RequestContext } from "./request/RequestContext";
/**
 * @hidden
 * This internal class implements the logic for endpoint management for geo-replicated database accounts.
 * @property {object} client                       - The document client instance.
 * @property {string} defaultEndpoint              - The endpoint used to create the client instance.
 * @property {bool} enableEndpointDiscovery        - Flag to enable/disable automatic redirecting of requests
 *                                                   based on read/write operations.
 * @property {Array} preferredLocations            - List of azure regions to be used as preferred locations
 *                                                   for read requests.
 * @property {bool} isEndpointCacheInitialized     - Flag to determine whether the endpoint cache is initialized or not.
 */
export declare class GlobalEndpointManager {
    private readDatabaseAccount;
    private defaultEndpoint;
    enableEndpointDiscovery: boolean;
    private isEndpointCacheInitialized;
    private locationCache;
    private isRefreshing;
    private readonly backgroundRefreshTimeIntervalInMS;
    /**
     * @constructor GlobalEndpointManager
     * @param {object} options                          - The document client instance.
     */
    constructor(options: CosmosClientOptions, readDatabaseAccount: (opts: RequestOptions) => Promise<CosmosResponse<DatabaseAccount, CosmosClient>>);
    /**
     * Gets the current read endpoint from the endpoint cache.
     */
    getReadEndpoint(): Promise<string>;
    /**
     * Gets the current write endpoint from the endpoint cache.
     */
    getWriteEndpoint(): Promise<string>;
    getReadEndpoints(): Promise<ReadonlyArray<string>>;
    getWriteEndpoints(): Promise<ReadonlyArray<string>>;
    markCurrentLocationUnavailableForRead(endpoint: string): void;
    markCurrentLocationUnavailableForWrite(endpoint: string): void;
    canUseMultipleWriteLocations(request: RequestContext): boolean;
    resolveServiceEndpoint(request: RequestContext): Promise<string>;
    /**
     * Refreshes the endpoint list by retrieving the writable and readable locations
     *  from the geo-replicated database account and then updating the locations cache.
     *   We skip the refreshing if EnableEndpointDiscovery is set to False
     */
    refreshEndpointList(): Promise<void>;
    private backgroundRefresh;
    /**
     * Gets the database account first by using the default endpoint, and if that doesn't returns
     * use the endpoints for the preferred locations in the order they are specified to get
     * the database account.
     * @memberof GlobalEndpointManager
     * @instance
     * @param {function} callback        - The callback function which takes databaseAccount(object) as an argument.
     */
    private getDatabaseAccountFromAnyEndpoint;
    /**
     * Gets the locational endpoint using the location name passed to it using the default endpoint.
     * @memberof GlobalEndpointManager
     * @instance
     * @param {string} defaultEndpoint - The default endpoint to use for the endpoint.
     * @param {string} locationName    - The location name for the azure region like "East US".
     */
    private static getLocationalEndpoint;
}
