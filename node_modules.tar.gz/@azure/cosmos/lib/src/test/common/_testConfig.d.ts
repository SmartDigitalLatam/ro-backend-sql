declare const masterKey: string;
declare const endpoint: string;
export { masterKey, endpoint };
