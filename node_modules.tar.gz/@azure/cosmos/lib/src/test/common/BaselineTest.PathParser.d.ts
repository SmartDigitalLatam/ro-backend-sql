declare const _default: {
    path: string;
    parts: string[];
}[];
export default _default;
