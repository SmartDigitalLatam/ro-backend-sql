/** @hidden */
export declare class MockedQueryIterator {
    private results;
    constructor(results: any);
    toArray(): Promise<{
        result: any;
    }>;
}
