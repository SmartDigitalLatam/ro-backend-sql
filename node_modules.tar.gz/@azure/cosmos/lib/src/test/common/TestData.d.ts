/** @hidden */
export declare class TestData {
    partitionKey: string;
    uniquePartitionKey: string;
    numberOfDocuments: number;
    field: string;
    numberOfDocsWithSamePartitionKey: number;
    numberOfDocumentsWithNumbericId: number;
    sum: number;
    docs: any[];
    constructor(partitionKey: string, uniquePartitionKey: string);
}
