import { MockedQueryIterator } from "./MockQueryIterator";
/** @hidden */
export declare class MockedClientContext {
    private partitionKeyRanges;
    private collectionId;
    constructor(partitionKeyRanges: any, collectionId: any);
    readPartitionKeyRanges(collectionLink: any): MockedQueryIterator;
    queryPartitionKeyRanges(collectionLink: any): MockedQueryIterator;
}
