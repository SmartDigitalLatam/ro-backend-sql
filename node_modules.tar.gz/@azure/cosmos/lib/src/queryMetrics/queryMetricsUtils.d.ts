import { TimeSpan } from "./timeSpan";
export declare class QueryMetricsUtils {
    static parseDelimitedString(delimitedString: string): {
        [key: string]: any;
    };
    static timeSpanFromMetrics(metrics: {
        [key: string]: any;
    }, key: string): TimeSpan;
    static isNumeric(input: any): boolean;
}
