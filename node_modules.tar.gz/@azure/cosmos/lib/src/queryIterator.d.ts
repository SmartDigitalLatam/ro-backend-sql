/// <reference lib="esnext.asynciterable" />
import { ClientContext } from "./ClientContext";
import { FetchFunctionCallback, IHeaders, SqlQuerySpec } from "./queryExecutionContext";
import { FeedOptions } from "./request/FeedOptions";
import { Response } from "./request/request";
/**
 * Represents a QueryIterator Object, an implmenetation of feed or query response that enables
 * traversal and iterating over the response
 * in the Azure Cosmos DB database service.
 */
export declare class QueryIterator<T> {
    private clientContext;
    private query;
    private options;
    private fetchFunctions;
    private resourceLink?;
    private toArrayTempResources;
    private toArrayLastResHeaders;
    private queryExecutionContext;
    /**
     * @hidden
     */
    constructor(clientContext: ClientContext, query: SqlQuerySpec | string, options: FeedOptions, fetchFunctions: FetchFunctionCallback | FetchFunctionCallback[], resourceLink?: string | string[]);
    /**
     * Calls a specified callback for each item returned from the query.
     * Runs serially; each callback blocks the next.
     *
     * @param callback Specified callback.
     * First param is the result,
     * second param (optional) is the current headers object state,
     * third param (optional) is current index.
     * No more callbacks will be called if one of them results false.
     *
     * @returns Promise<void> - you should await or .catch the Promise in case there are any errors
     *
     * @example Iterate over all databases
     * ```typescript
     * await client.databases.readAll().forEach((db, headers, index) => {
     *   console.log(`Got ${db.id} from forEach`);
     * })
     * ```
     */
    forEach(callback: (result: T, headers?: IHeaders, index?: number) => boolean | void): Promise<void>;
    /**
     * Gets an async iterator that will yield results until completion.
     *
     * NOTE: AsyncIterators are a very new feature and you might need to
     * use polyfils/etc. in order to use them in your code.
     *
     * If you're using TypeScript, you can use the following polyfill as long
     * as you target ES6 or higher and are running on Node 6 or higher.
     *
     * ```typescript
     * if (!Symbol || !Symbol.asyncIterator) {
     *   (Symbol as any).asyncIterator = Symbol.for("Symbol.asyncIterator");
     * }
     * ```
     *
     * @see QueryIterator.forEach for very similar functionality.
     *
     * @example Iterate over all databases
     * ```typescript
     * for await(const {result: db} in client.databases.readAll().getAsyncIterator()) {
     *   console.log(`Got ${db.id} from AsyncIterator`);
     * }
     * ```
     */
    getAsyncIterator(): AsyncIterable<Response<T>>;
    /**
     * Execute a provided function on the next element in the QueryIterator.
     */
    nextItem(): Promise<Response<T>>;
    /**
     * Retrieve the current element on the QueryIterator.
     */
    current(): Promise<Response<T>>;
    /**
     * @deprecated Instead check if nextItem() or current() returns undefined.
     *
     * Determine if there are still remaining resources to processs based on the value of the continuation token or the\
     * elements remaining on the current batch in the QueryIterator.
     * @returns {Boolean} true if there is other elements to process in the QueryIterator.
     */
    hasMoreResults(): boolean;
    /**
     * Retrieve all the elements of the feed and pass them as an array to a function
     */
    toArray(): Promise<Response<T[]>>;
    /**
     * Retrieve the next batch of the feed and pass them as an array to a function
     */
    executeNext(): Promise<Response<T[]>>;
    /**
     * Reset the QueryIterator to the beginning and clear all the resources inside it
     */
    reset(): void;
    private _toArrayImplementation;
    private _createQueryExecutionContext;
}
