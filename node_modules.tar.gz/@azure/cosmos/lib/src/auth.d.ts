import { PermissionDefinition } from "./client";
import { IHeaders } from "./queryExecutionContext";
/** @hidden */
export interface IRequestInfo {
    [index: string]: any;
    verb: string;
    path: string;
    resourceId: string;
    resourceType: string;
    headers: IHeaders;
}
export interface ITokenProvider {
    getToken: (requestInfo: IRequestInfo, callback?: (err: Error, token: string) => void) => Promise<string>;
}
export interface AuthOptions {
    /** Account master key or read only key */
    key?: string;
    /** The authorization master key to use to create the client. */
    masterKey?: string;
    /** An object that contains resources tokens.
     * Keys for the object are resource Ids and values are the resource tokens.
     */
    resourceTokens?: {
        [resourcePath: string]: string;
    };
    tokenProvider?: any;
    /** An array of {@link Permission} objects. */
    permissionFeed?: PermissionDefinition[];
}
/** @hidden */
export declare class AuthHandler {
    static getAuthorizationHeader(authOptions: AuthOptions, verb: string, path: string, resourceId: string, resourceType: string, headers: IHeaders): Promise<string>;
    private static getAuthorizationTokenUsingMasterKey;
    private static getAuthorizationTokenUsingResourceTokens;
    private static getAuthorizationTokenUsingTokenProvider;
}
