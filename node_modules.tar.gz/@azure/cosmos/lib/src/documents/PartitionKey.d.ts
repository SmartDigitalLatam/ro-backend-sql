import { Point, Range } from "../range";
import { PartitionKeyDefinition } from "./PartitionKeyDefinition";
export declare type PartitionKey = PartitionKeyDefinition | Point | Range;
