export declare enum PartitionKind {
    Hash = "Hash"
}
