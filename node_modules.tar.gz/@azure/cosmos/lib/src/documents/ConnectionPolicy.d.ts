import { ConnectionMode, MediaReadMode } from ".";
import { RetryOptions } from "../retry";
/**
 * Represents the Connection policy associated with a CosmosClient in the Azure Cosmos DB database service.
 */
export declare class ConnectionPolicy {
    private static readonly defaultRequestTimeout;
    private static readonly defaultMediaRequestTimeout;
    /** Determines which mode to connect to Cosmos with. (Currently only supports Gateway option) */
    ConnectionMode: ConnectionMode;
    /** Attachment content (aka media) download mode. Should be one of the values of {@link MediaReadMode} */
    MediaReadMode: keyof typeof MediaReadMode;
    /** Time to wait for response from network peer for attachment content (aka media) operations. Represented in milliseconds. */
    MediaRequestTimeout: number;
    /** Request timeout (time to wait for response from network peer). Represented in milliseconds. */
    RequestTimeout: number;
    /** Flag to enable/disable automatic redirecting of requests based on read/write operations. */
    EnableEndpointDiscovery: boolean;
    /** List of azure regions to be used as preferred locations for read requests. */
    PreferredLocations: string[];
    /** RetryOptions instance which defines several configurable properties used during retry. */
    RetryOptions: RetryOptions;
    /**
     * Flag to disable SSL verification for the requests. SSL verification is enabled by default. Don't set this when targeting production endpoints.
     * This is intended to be used only when targeting emulator endpoint to avoid failing your requests with SSL related error.
     */
    DisableSSLVerification: boolean;
    /** Http/Https proxy url */
    ProxyUrl: string;
    /**
     * The flag that enables writes on any locations (regions) for geo-replicated database accounts in the Azure Cosmos DB service.
     * Default is `false`.
     */
    UseMultipleWriteLocations: boolean;
}
