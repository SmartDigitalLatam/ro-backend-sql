import { ConsistencyLevel } from ".";
import { IHeaders } from "../queryExecutionContext";
/**
 * Represents a DatabaseAccount in the Azure Cosmos DB database service.
 */
export declare class DatabaseAccount {
    /** The list of writable locations for a geo-replicated database account. */
    readonly writableLocations: Location[];
    /** The list of readable locations for a geo-replicated database account. */
    readonly readableLocations: Location[];
    /** The self-link for Databases in the databaseAccount. */
    readonly DatabasesLink: string;
    /** The self-link for Media in the databaseAccount. */
    readonly MediaLink: string;
    /** Attachment content (media) storage quota in MBs ( Retrieved from gateway ). */
    readonly MaxMediaStorageUsageInMB: number;
    /**
     * Current attachment content (media) usage in MBs (Retrieved from gateway )
     *
     * Value is returned from cached information updated periodically and is not guaranteed
     * to be real time.
     */
    readonly CurrentMediaStorageUsageInMB: number;
    /** Gets the UserConsistencyPolicy settings. */
    readonly ConsistencyPolicy: ConsistencyLevel;
    readonly enableMultipleWritableLocations: boolean;
    constructor(body: {
        [key: string]: any;
    }, headers: IHeaders);
}
/**
 * Used to specify the locations that are available, read is index 1 and write is index 0.
 */
export interface Location {
    name: string;
    databaseAccountEndpoint: string;
}
