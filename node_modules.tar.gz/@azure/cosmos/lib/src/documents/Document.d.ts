export interface Document {
    [key: string]: any;
}
