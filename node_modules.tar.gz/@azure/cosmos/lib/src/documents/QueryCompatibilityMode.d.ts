export declare enum QueryCompatibilityMode {
    Default = 0,
    Query = 1,
    SqlQuery = 2
}
