import { CompareFunction, Range } from ".";
import { Document, PartitionKey } from "../documents";
/** @hidden */
export declare type PartitionKeyExtractorFunction = (obj: object) => PartitionKey;
/** @hidden */
export declare type PartitionKeyExtractor = string | PartitionKeyExtractorFunction;
/** @hidden */
export interface PartitionKeyMapItem {
    range: Range;
    link: string;
}
/** @hidden */
export declare class RangePartitionResolver {
    partitionKeyExtractor: PartitionKeyExtractor;
    partitionKeyMap: PartitionKeyMapItem[];
    compareFunction: CompareFunction;
    /**
     * RangePartitionResolver implements partitioning using a partition map of ranges of values to a \
     * collection link in the Azure Cosmos DB database service.
     * @class RangePartitionResolver
     * @param {PartitionKeyExtractor} partitionKeyExtractor   - If partitionKeyExtractor is a string, \
     * it should be the name of the property in the document to execute the hashing on.
     *                                                      If partitionKeyExtractor is a function, \
     * it should be a function to extract the partition key from an object.
     * @param {Array} partitionKeyMap                     - The map from Range to collection link that\
     *  is used for partitioning requests.
     * @param {function} compareFunction                  - Optional function that accepts two arguments\
     *  x and y and returns a negative value if x < y, zero if x = y, or a positive value if x > y.
     */
    constructor(partitionKeyExtractor: PartitionKeyExtractor, partitionKeyMap: PartitionKeyMapItem[], compareFunction?: CompareFunction);
    /**
     * Extracts the partition key from the specified document using the partitionKeyExtractor
     * @memberof RangePartitionResolver
     * @instance
     * @param {object} document - The document from which to extract the partition key.
     * @returns {}
     */
    getPartitionKey(document: Document): PartitionKey;
    /**
     * Given a partition key, returns the correct collection link for creating a document using the range partition map.
     * @memberof RangePartitionResolver
     * @instance
     * @param {any} partitionKey - The partition key used to determine the target collection for create
     * @returns {string}         - The target collection link that will be used for document creation.
     */
    resolveForCreate(partitionKey: PartitionKey): string;
    /**
     * Given a partition key, returns a list of collection links to read from using the range partition map.
     * @memberof RangePartitionResolver
     * @instance
     * @param {any} partitionKey - The partition key used to determine the target collection for query
     * @returns {string[]}         - The list of target collection links.
     */
    resolveForRead(partitionKey: PartitionKey): any[];
    _getFirstContainingMapEntryOrNull(point: any): PartitionKeyMapItem;
    getFirstContainingMapEntryOrNull(point: any): PartitionKeyMapItem;
    _getIntersectingMapEntries(partitionKey: PartitionKey): any[];
}
