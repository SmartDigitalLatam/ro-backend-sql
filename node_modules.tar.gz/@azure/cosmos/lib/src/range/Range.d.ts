import { PartitionKey } from "../documents";
/** @hidden */
export declare type CompareFunction = (x: Point, y: Point) => number;
/** @hidden */
export declare type Point = number | string;
/** @hidden */
export declare class Range {
    readonly low: Point;
    readonly high: Point;
    /**
     * Represents a range object used by the RangePartitionResolver in the Azure Cosmos DB database service.
     * @class Range
     * @param {object} options                   - The Range constructor options.
     * @param {any} options.low                  - The low value in the range.
     * @param {any} options.high                 - The high value in the range.
     */
    constructor(options?: any);
    _compare(x: Point, y: Point, compareFunction?: CompareFunction): number;
    _contains: (other: string | number | Range, compareFunction?: CompareFunction) => boolean;
    contains(other: Point | Range, compareFunction?: CompareFunction): boolean;
    _containsPoint(point: Point, compareFunction?: CompareFunction): boolean;
    _containsRange(range: Range, compareFunction?: CompareFunction): boolean;
    _intersect: (range: Range, compareFunction?: CompareFunction) => boolean;
    intersect(range: Range, compareFunction?: CompareFunction): boolean;
    _toString: () => string;
    toString(): string;
    static _isRange: typeof Range.isRange;
    static isRange(pointOrRange: Point | Range | PartitionKey): boolean;
}
