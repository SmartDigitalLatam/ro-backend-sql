export declare class LocationRouting {
    private pIgnorePreferredLocation;
    private pLocationIndexToRoute;
    private pLocationEndpointToRoute;
    readonly ignorePreferredLocation: boolean;
    readonly locationIndexToRoute: number;
    readonly locationEndpointToRoute: string;
    routeToLocation(locationEndpoint: string): void;
    routeToLocation(locationIndex: number, ignorePreferredLocation: boolean): void;
    clearRouteToLocation(): void;
}
