/// <reference types="node" />
import { Agent } from "http";
import { RequestOptions } from "https";
import { IHeaders } from "..";
import { AuthOptions } from "../auth";
import { ConnectionPolicy } from "../documents";
import { GlobalEndpointManager } from "../globalEndpointManager";
import { Response } from "./request";
import { RequestContext } from "./RequestContext";
/** @hidden */
export declare class RequestHandler {
    private globalEndpointManager;
    private connectionPolicy;
    private requestAgent;
    constructor(globalEndpointManager: GlobalEndpointManager, connectionPolicy: ConnectionPolicy, requestAgent: Agent);
    static createRequestObjectStub(connectionPolicy: ConnectionPolicy, requestOptions: RequestOptions, body: Buffer): Promise<Response<any>>;
    /**
     *  Creates the request object, call the passed callback when the response is retrieved.
     * @param {object} globalEndpointManager - an instance of GlobalEndpointManager class.
     * @param {object} connectionPolicy - an instance of ConnectionPolicy that has the connection configs.
     * @param {object} requestAgent - the https agent used for send request
     * @param {string} method - the http request method ( 'get', 'post', 'put', .. etc ).
     * @param {String} hostname - The base url for the endpoint.
     * @param {string} path - the path of the requesed resource.
     * @param {Object} data - the request body. It can be either string, buffer, or undefined.
     * @param {Object} queryParams - query parameters for the request.
     * @param {Object} headers - specific headers for the request.
     * @param {function} callback - the callback that will be called when the response is retrieved and processed.
     */
    static request(globalEndpointManager: GlobalEndpointManager, connectionPolicy: ConnectionPolicy, requestAgent: Agent, method: string, hostname: string, request: RequestContext, data: string | Buffer, queryParams: any, // TODO: any query params types
    headers: IHeaders, authOptions: AuthOptions, resourceId: string, resourceType: string): Promise<Response<any>>;
    /** @ignore */
    get(urlString: string, request: RequestContext, headers: IHeaders, authOptions: AuthOptions, resourceId: string, resourceType: string): Promise<Response<any>>;
    /** @ignore */
    post(urlString: string, request: RequestContext, body: any, headers: IHeaders, authOptions: AuthOptions, resourceId: string, resourceType: string): Promise<Response<any>>;
    /** @ignore */
    put(urlString: string, request: RequestContext, body: any, headers: IHeaders, authOptions: AuthOptions, resourceId: string, resourceType: string): Promise<Response<any>>;
    /** @ignore */
    head(urlString: string, request: any, headers: IHeaders, authOptions: AuthOptions, resourceId: string, resourceType: string): Promise<Response<any>>;
    /** @ignore */
    delete(urlString: string, request: RequestContext, headers: IHeaders, authOptions: AuthOptions, resourceId: string, resourceType: string): Promise<Response<any>>;
}
