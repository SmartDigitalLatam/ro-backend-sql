/// <reference types="node" />
import * as https from "https";
import { Stream } from "stream";
import * as url from "url";
import { ConnectionPolicy } from "../documents";
import { IHeaders } from "../queryExecutionContext";
import { ErrorResponse } from "./ErrorResponse";
export { ErrorResponse };
import { FeedOptions, MediaOptions, RequestOptions } from ".";
import { AuthOptions } from "../auth";
import { Response } from "./Response";
export { Response };
/** @hidden */
export declare function bodyFromData(data: Stream | Buffer | string | object): string | object;
/** @hidden */
export declare function parse(urlString: string): url.UrlWithStringQuery;
/** @hidden */
export declare function createRequestObject(connectionPolicy: ConnectionPolicy, requestOptions: https.RequestOptions, body: Buffer): Promise<Response<any>>;
export declare function getHeaders(authOptions: AuthOptions, defaultHeaders: IHeaders, verb: string, path: string, resourceId: string, resourceType: string, options: RequestOptions | FeedOptions | MediaOptions, partitionKeyRangeId?: string, useMultipleWriteLocations?: boolean): Promise<IHeaders>;
