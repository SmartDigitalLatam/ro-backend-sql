import { IHeaders } from "..";
import { ConnectionPolicy } from "../documents";
import { RequestContext } from "../request/RequestContext";
/** @hidden */
export declare class Helper {
    static jsonStringifyAndEscapeNonASCII(arg: any): string;
    static parseLink(resourcePath: string): {
        type: string;
        objectBody: {
            id: string;
            self: string;
        };
    };
    static isReadRequest(request: RequestContext): boolean;
    static sleep(time: number): Promise<void>;
    static getContainerLink(link: string): string;
    static trimSlashes(source: string): string;
    static getHexaDigit(): string;
    static setIsUpsertHeader(headers: IHeaders): void;
    static generateGuidId(): string;
    static parsePath(path: string): string[];
    static isResourceValid(resource: any, err: any): boolean;
    /** @ignore */
    static getIdFromLink(resourceLink: string, isNameBased?: boolean): string;
    /** @ignore */
    static getPathFromLink(resourceLink: string, resourceType?: string, isNameBased?: boolean): string;
    static isStringNullOrEmpty(inputString: string): boolean;
    static trimSlashFromLeftAndRight(inputString: string): string;
    static validateResourceId(resourceId: string): boolean;
    static getResourceIdFromPath(resourcePath: string): string;
    static parseConnectionPolicy(policy: any): ConnectionPolicy;
}
