/// <reference lib="esnext.asynciterable" />
import { ChangeFeedOptions } from "./ChangeFeedOptions";
import { ChangeFeedResponse } from "./ChangeFeedResponse";
import { Resource } from "./client";
import { ClientContext } from "./ClientContext";
/**
 * Provides iterator for change feed.
 *
 * Use `Items.readChangeFeed()` to get an instance of the iterator.
 */
export declare class ChangeFeedIterator<T> {
    private clientContext;
    private resourceId;
    private resourceLink;
    private partitionKey;
    private isPartitionedContainer;
    private changeFeedOptions;
    private static readonly IfNoneMatchAllHeaderValue;
    private nextIfNoneMatch;
    private ifModifiedSince;
    private lastStatusCode;
    private isPartitionSpecified;
    /**
     * @internal
     * @hidden
     *
     * @param clientContext
     * @param resourceId
     * @param resourceLink
     * @param isPartitionedContainer
     * @param changeFeedOptions
     */
    constructor(clientContext: ClientContext, resourceId: string, resourceLink: string, partitionKey: string | number | boolean, isPartitionedContainer: () => Promise<boolean>, changeFeedOptions: ChangeFeedOptions);
    /**
     * Gets a value indicating whether there are potentially additional results that can be retrieved.
     *
     * Initially returns true. This value is set based on whether the last execution returned a continuation token.
     *
     * @returns Boolean value representing if whether there are potentially additional results that can be retrieved.
     */
    readonly hasMoreResults: boolean;
    /**
     * Gets an async iterator which will yield pages of results from Azure Cosmos DB.
     */
    getAsyncIterator(): AsyncIterable<ChangeFeedResponse<Array<T & Resource>>>;
    /**
     * Read feed and retrieves the next page of results in Azure Cosmos DB.
     */
    executeNext(): Promise<ChangeFeedResponse<Array<T & Resource>>>;
    private getFeedResponse;
}
