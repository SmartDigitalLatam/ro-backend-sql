import { ErrorResponse } from "../request/request";
/**
 * This class implements the resource throttle retry policy for requests.
 * @hidden
 */
export declare class ResourceThrottleRetryPolicy {
    private maxRetryAttemptCount;
    private fixedRetryIntervalInMilliseconds;
    /** Current retry attempt count. */
    currentRetryAttemptCount: number;
    /** Cummulative wait time in milliseconds for a request while the retries are happening. */
    cummulativeWaitTimeinMilliseconds: number;
    /** Max wait time in milliseconds to wait for a request while the retries are happening. */
    retryAfterInMilliseconds: number;
    /** Max number of retries to be performed for a request. */
    private maxWaitTimeInMilliseconds;
    /**
     * @constructor ResourceThrottleRetryPolicy
     * @param {int} maxRetryAttemptCount               - Max number of retries to be performed for a request.
     * @param {int} fixedRetryIntervalInMilliseconds   - Fixed retry interval in milliseconds to wait between each \
     * retry ignoring the retryAfter returned as part of the response.
     * @param {int} maxWaitTimeInSeconds               - Max wait time in seconds to wait for a request while the \
     * retries are happening.
     */
    constructor(maxRetryAttemptCount: number, fixedRetryIntervalInMilliseconds: number, maxWaitTimeInSeconds: number);
    /**
     * Determines whether the request should be retried or not.
     * @param {object} err - Error returned by the request.
     */
    shouldRetry(err: ErrorResponse): Promise<boolean>;
}
