import { ErrorResponse } from "../request";
/**
 * This class implements the default connection retry policy for requests.
 * @property {int} currentRetryAttemptCount           - Current retry attempt count.
 * @hidden
 */
export declare class DefaultRetryPolicy {
    private operationType;
    private maxRetryAttemptCount;
    private currentRetryAttemptCount;
    retryAfterInMilliseconds: number;
    private WindowsInterruptedFunctionCall;
    private WindowsFileHandleNotValid;
    private WindowsPermissionDenied;
    private WindowsBadAddress;
    private WindowsInvalidArgumnet;
    private WindowsResourceTemporarilyUnavailable;
    private WindowsOperationNowInProgress;
    private WindowsAddressAlreadyInUse;
    private WindowsConnectionResetByPeer;
    private WindowsCannotSendAfterSocketShutdown;
    private WindowsConnectionTimedOut;
    private WindowsConnectionRefused;
    private WindowsNameTooLong;
    private WindowsHostIsDown;
    private WindowsNoRouteTohost;
    private LinuxConnectionReset;
    private CONNECTION_ERROR_CODES;
    /**
     * @constructor ResourceThrottleRetryPolicy
     * @param {string} operationType - The type of operation being performed.
     */
    constructor(operationType: string);
    /**
     * Determines whether the request should be retried or not.
     * @param {object} err - Error returned by the request.
     * @param {function} callback - The callback function which takes bool argument which
     *                              specifies whether the request will be retried or not.
     */
    shouldRetry(err: ErrorResponse): Promise<boolean>;
    private needs_retry;
}
