/// <reference types="node" />
import { RequestOptions } from "https";
import { EndpointDiscoveryRetryPolicy, ResourceThrottleRetryPolicy, SessionRetryPolicy } from ".";
import { AuthOptions } from "../auth";
import { ConnectionPolicy } from "../documents";
import { GlobalEndpointManager } from "../globalEndpointManager";
import { Response } from "../request";
import { RequestContext } from "../request/RequestContext";
import { DefaultRetryPolicy } from "./defaultRetryPolicy";
import { RetryContext } from "./RetryContext";
/** @hidden */
export declare type CreateRequestObjectStubFunction = (connectionPolicy: ConnectionPolicy, requestOptions: RequestOptions, body: Buffer) => Promise<Response<any>>;
/** @hidden */
export declare class RetryUtility {
    /**
     * Executes the retry policy for the created request object.
     * @param {object} globalEndpointManager - an instance of GlobalEndpointManager class.
     * @param {object} body - request body. A buffer or a string.
     * @param {function} createRequestObjectStub - stub function that creates the request object.
     * @param {object} connectionPolicy - an instance of ConnectionPolicy that has the connection configs.
     * @param {RequestOptions} requestOptions - The request options.
     * @param {function} callback - the callback that will be called when the request is finished executing.
     */
    static execute(globalEndpointManager: GlobalEndpointManager, body: Buffer, createRequestObjectFunc: CreateRequestObjectStubFunction, connectionPolicy: ConnectionPolicy, requestOptions: RequestOptions, request: RequestContext, authOptions: AuthOptions, resourceId: string, resourceType: string): Promise<Response<any>>;
    /**
     * Applies the retry policy for the created request object.
     * @param {object} body - request body. A buffer or a string.
     * @param {function} createRequestObjectFunc - function that creates the request object.
     * @param {object} connectionPolicy - an instance of ConnectionPolicy that has the connection configs.
     * @param {RequestOptions} requestOptions - The request options.
     * @param {EndpointDiscoveryRetryPolicy} endpointDiscoveryRetryPolicy - The endpoint discovery retry policy \
     * instance.
     * @param {ResourceThrottleRetryPolicy} resourceThrottleRetryPolicy - The resource throttle retry policy instance.
     * @param {function} callback - the callback that will be called when the response is retrieved and processed.
     */
    static apply(body: Buffer, createRequestObjectFunc: CreateRequestObjectStubFunction, connectionPolicy: ConnectionPolicy, requestOptions: RequestOptions, endpointDiscoveryRetryPolicy: EndpointDiscoveryRetryPolicy, resourceThrottleRetryPolicy: ResourceThrottleRetryPolicy, sessionReadRetryPolicy: SessionRetryPolicy, defaultRetryPolicy: DefaultRetryPolicy, globalEndpointManager: GlobalEndpointManager, request: RequestContext, retryContext: RetryContext, authOptions: AuthOptions, resourceId: string, resourceType: string): Promise<Response<any>>;
    private static modifyRequestOptions;
}
