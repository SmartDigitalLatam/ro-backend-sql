import { GlobalEndpointManager } from "../globalEndpointManager";
import { ErrorResponse } from "../request/request";
import { RequestContext } from "../request/RequestContext";
import { IRetryPolicy } from "./IRetryPolicy";
import { RetryContext } from "./RetryContext";
/**
 * This class implements the retry policy for endpoint discovery.
 * @hidden
 */
export declare class EndpointDiscoveryRetryPolicy implements IRetryPolicy {
    private globalEndpointManager;
    private request;
    /** Current retry attempt count. */
    currentRetryAttemptCount: number;
    /** Retry interval in milliseconds. */
    retryAfterInMilliseconds: number;
    /** Max number of retry attempts to perform. */
    private maxRetryAttemptCount;
    private static readonly maxRetryAttemptCount;
    private static readonly retryAfterInMilliseconds;
    /**
     * @constructor EndpointDiscoveryRetryPolicy
     * @param {object} globalEndpointManager The GlobalEndpointManager instance.
     */
    constructor(globalEndpointManager: GlobalEndpointManager, request: RequestContext);
    /**
     * Determines whether the request should be retried or not.
     * @param {object} err - Error returned by the request.
     */
    shouldRetry(err: ErrorResponse, retryContext?: RetryContext, locationEndpoint?: string): Promise<boolean | [boolean, string]>;
}
