import { ConnectionPolicy } from "../documents";
import { GlobalEndpointManager } from "../globalEndpointManager";
import { ErrorResponse } from "../request/request";
import { RequestContext } from "../request/RequestContext";
import { IRetryPolicy } from "./IRetryPolicy";
import { RetryContext } from "./RetryContext";
/**
 * This class implements the retry policy for session consistent reads.
 * @hidden
 */
export declare class SessionRetryPolicy implements IRetryPolicy {
    private globalEndpointManager;
    private request;
    private connectionPolicy;
    /** Current retry attempt count. */
    currentRetryAttemptCount: number;
    /** Retry interval in milliseconds. */
    retryAfterInMilliseconds: number;
    /**
     * @constructor SessionReadRetryPolicy
     * @param {object} globalEndpointManager                           - The GlobalEndpointManager instance.
     * @property {object} request                                      - The Http request information
     */
    constructor(globalEndpointManager: GlobalEndpointManager, request: RequestContext, connectionPolicy: ConnectionPolicy);
    /**
     * Determines whether the request should be retried or not.
     * @param {object} err - Error returned by the request.
     * @param {function} callback - The callback function which takes bool argument which specifies whether the request\
     * will be retried or not.
     */
    shouldRetry(err: ErrorResponse, retryContext?: RetryContext): Promise<boolean>;
}
