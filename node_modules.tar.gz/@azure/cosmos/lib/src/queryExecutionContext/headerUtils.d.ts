export interface IHeaders {
    [key: string]: any;
}
/** @hidden */
export declare class HeaderUtils {
    static getRequestChargeIfAny(headers: IHeaders): number;
    static getInitialHeader(): IHeaders;
    static mergeHeaders(headers: IHeaders, toBeMergedHeaders: IHeaders): void;
}
