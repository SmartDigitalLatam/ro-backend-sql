import { IExecutionContext, PartitionedQueryExecutionContextInfo } from ".";
import { ClientContext } from "../ClientContext";
import { Response } from "../request/request";
/** @hidden */
export declare class PipelinedQueryExecutionContext implements IExecutionContext {
    private clientContext;
    private collectionLink;
    private query;
    private options;
    private partitionedQueryExecutionInfo;
    private fetchBuffer;
    private fetchMoreRespHeaders;
    private endpoint;
    private pageSize;
    private static DEFAULT_PAGE_SIZE;
    constructor(clientContext: ClientContext, collectionLink: string, query: any, // TODO: any query
    options: any, // TODO: any options
    partitionedQueryExecutionInfo: PartitionedQueryExecutionContextInfo);
    nextItem(): Promise<Response<any>>;
    current(): Promise<Response<any>>;
    hasMoreResults(): boolean;
    fetchMore(): Promise<Response<any>>;
    private _fetchMoreImplementation;
}
