export interface IHeaders {
    [key: string]: string | boolean | number;
}
