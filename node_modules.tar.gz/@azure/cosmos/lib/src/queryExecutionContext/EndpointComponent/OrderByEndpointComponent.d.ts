import { Response } from "../../request/request";
import { IExecutionContext } from "../IExecutionContext";
import { IEndpointComponent } from "./IEndpointComponent";
/** @hidden */
export declare class OrderByEndpointComponent implements IEndpointComponent {
    private executionContext;
    /**
     * Represents an endpoint in handling an order by query. For each processed orderby \
     * result it returns 'payload' item of the result
     * @constructor OrderByEndpointComponent
     * @param {object} executionContext              - Underlying Execution Context
     * @ignore
     */
    constructor(executionContext: IExecutionContext);
    /**
     * Execute a provided function on the next element in the OrderByEndpointComponent.
     * @memberof OrderByEndpointComponent
     * @instance
     * @param {callback} callback - Function to execute for each element. the function \
     * takes two parameters error, element.
     */
    nextItem(): Promise<Response<any>>;
    /**
     * Retrieve the current element on the OrderByEndpointComponent.
     * @memberof OrderByEndpointComponent
     * @instance
     * @param {callback} callback - Function to execute for the current element. \
     * the function takes two parameters error, element.
     */
    current(): Promise<Response<any>>;
    /**
     * Determine if there are still remaining resources to processs.
     * @memberof OrderByEndpointComponent
     * @instance
     * @returns {Boolean} true if there is other elements to process in the OrderByEndpointComponent.
     */
    hasMoreResults(): boolean;
}
