import { Response } from "../../request/request";
import { IExecutionContext } from "../IExecutionContext";
import { IEndpointComponent } from "./IEndpointComponent";
/** @hidden */
export declare class AggregateEndpointComponent implements IEndpointComponent {
    private executionContext;
    private toArrayTempResources;
    private aggregateValues;
    private aggregateValuesIndex;
    private localAggregators;
    /**
     * Represents an endpoint in handling aggregate queries.
     * @constructor AggregateEndpointComponent
     * @param { object } executionContext - Underlying Execution Context
     * @ignore
     */
    constructor(executionContext: IExecutionContext, aggregateOperators: string[]);
    /**
     * Populate the aggregated values
     * @ignore
     */
    private _getAggregateResult;
    /**
     * Get the results of queries from all partitions
     * @ignore
     */
    _getQueryResults(): Promise<Response<any>>;
    /**
     * Execute a provided function on the next element in the AggregateEndpointComponent.
     * @memberof AggregateEndpointComponent
     * @instance
     * @param {callback} callback - Function to execute for each element. \
     * the function takes two parameters error, element.
     */
    nextItem(): Promise<Response<any>>;
    /**
     * Retrieve the current element on the AggregateEndpointComponent.
     * @memberof AggregateEndpointComponent
     * @instance
     * @param {callback} callback - Function to execute for the current element. \
     * the function takes two parameters error, element.
     */
    current(): Promise<Response<any>>;
    /**
     * Determine if there are still remaining resources to processs.
     * @memberof AggregateEndpointComponent
     * @instance
     * @returns {Boolean} true if there is other elements to process in the AggregateEndpointComponent.
     */
    hasMoreResults(): boolean;
}
