import { FetchFunctionCallback, SqlQuerySpec } from ".";
import { ClientContext } from "../ClientContext";
import { FeedOptions } from "../request";
import { Response } from "../request/request";
import { FetchResult } from "./FetchResult";
/** @hidden */
export declare class DocumentProducer {
    private clientContext;
    private static readonly STATES;
    private collectionLink;
    private query;
    targetPartitionKeyRange: any;
    fetchResults: FetchResult[];
    private state;
    allFetched: boolean;
    private err;
    previousContinuationToken: string;
    continuationToken: string;
    private respHeaders;
    private internalExecutionContext;
    /**
     * Provides the Target Partition Range Query Execution Context.
     * @constructor DocumentProducer
     * @param {ClientContext} clientContext        - The service endpoint to use to create the client.
     * @param {String} collectionLink                - Represents collection link
     * @param {SqlQuerySpec | string} query          - A SQL query.
     * @param {object} targetPartitionKeyRange       - Query Target Partition key Range
     * @ignore
     */
    constructor(clientContext: ClientContext, collectionLink: string, query: SqlQuerySpec, targetPartitionKeyRange: any, // TODO: any partition key range
    options: FeedOptions);
    /**
     * Synchronously gives the contiguous buffered results (stops at the first non result) if any
     * @returns {Object}       - buffered current items if any
     * @ignore
     */
    peekBufferedItems(): any[];
    fetchFunction: FetchFunctionCallback;
    hasMoreResults(): boolean;
    gotSplit(): boolean;
    private _getAndResetActiveResponseHeaders;
    private _updateStates;
    private static _needPartitionKeyRangeCacheRefresh;
    /**
     * Fetches and bufferes the next page of results and executes the given callback
     * @memberof DocumentProducer
     * @instance
     */
    bufferMore(): Promise<Response<any>>;
    /**
     * Synchronously gives the bufferend current item if any
     * @returns {Object}       - buffered current item if any
     * @ignore
     */
    getTargetParitionKeyRange(): any;
    /**
     * Execute a provided function on the next element in the DocumentProducer.
     * @memberof DocumentProducer
     * @instance
     * @param {callback} callback - Function to execute for each element. the function \
     * takes two parameters error, element.
     */
    nextItem(): Promise<Response<any>>;
    /**
     * Retrieve the current element on the DocumentProducer.
     * @memberof DocumentProducer
     * @instance
     * @param {callback} callback - Function to execute for the current element. \
     * the function takes two parameters error, element.
     */
    current(): Promise<Response<any>>;
}
