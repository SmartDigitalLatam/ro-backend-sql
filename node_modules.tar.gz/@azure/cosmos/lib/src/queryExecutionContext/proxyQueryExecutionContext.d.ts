import { FetchFunctionCallback, IExecutionContext, SqlQuerySpec } from ".";
import { ClientContext } from "../ClientContext";
import { Response } from "../request/request";
/** @hidden */
export declare class ProxyQueryExecutionContext implements IExecutionContext {
    private clientContext;
    private query;
    private options;
    private fetchFunctions;
    private resourceLink;
    private queryExecutionContext;
    constructor(clientContext: ClientContext, query: SqlQuerySpec | string, options: any, // TODO: any options
    fetchFunctions: FetchFunctionCallback | FetchFunctionCallback[], resourceLink: string | string[]);
    /**
     * Execute a provided function on the next element in the ProxyQueryExecutionContext.
     * @memberof ProxyQueryExecutionContext
     * @instance
     * @param {callback} callback - Function to execute for each element. \
     * the function takes two parameters error, element.
     */
    nextItem(): Promise<Response<any>>;
    private _createPipelinedExecutionContext;
    /**
     * Retrieve the current element on the ProxyQueryExecutionContext.
     * @memberof ProxyQueryExecutionContext
     * @instance
     * @param {callback} callback - Function to execute for the current element. \
     * the function takes two parameters error, element.
     */
    current(): Promise<Response<any>>;
    /**
     * Determine if there are still remaining resources to process.
     * @memberof ProxyQueryExecutionContext
     * @instance
     * @returns {Boolean} true if there is other elements to process in the ProxyQueryExecutionContext.
     */
    hasMoreResults(): boolean;
    fetchMore(): Promise<Response<any>>;
    private _hasPartitionedExecutionInfo;
    private _getParitionedExecutionInfo;
}
