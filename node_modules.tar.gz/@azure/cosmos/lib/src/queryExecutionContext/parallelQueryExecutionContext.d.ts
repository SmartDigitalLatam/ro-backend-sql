import { DocumentProducer, IExecutionContext, ParallelQueryExecutionContextBase, PartitionedQueryExecutionContextInfo } from ".";
import { ClientContext } from "../ClientContext";
/** @hidden */
export declare class ParallelQueryExecutionContext extends ParallelQueryExecutionContextBase implements IExecutionContext {
    /**
     * Provides the ParallelQueryExecutionContext.
     * This class is capable of handling parallelized queries and dervives from ParallelQueryExecutionContextBase.
     *
     * @constructor ParallelQueryExecutionContext
     * @param {ClientContext} clientContext        - The service endpoint to use to create the client.
     * @param {string} collectionLink                - The Collection Link
     * @param {FeedOptions} [options]                - Represents the feed options.
     * @param {object} partitionedQueryExecutionInfo - PartitionedQueryExecutionInfo
     * @ignore
     */
    constructor(clientContext: ClientContext, collectionLink: string, query: any, options: any, partitionedQueryExecutionInfo: PartitionedQueryExecutionContextInfo);
    /**
     * Provides a Comparator for document producers using the min value of the corresponding target partition.
     * @returns {object}        - Comparator Function
     * @ignore
     */
    documentProducerComparator(docProd1: DocumentProducer, docProd2: DocumentProducer): 1 | -1 | 0;
    private _buildContinuationTokenFrom;
}
