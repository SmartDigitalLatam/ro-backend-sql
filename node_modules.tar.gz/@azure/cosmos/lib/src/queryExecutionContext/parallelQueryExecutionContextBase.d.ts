import { DocumentProducer, IExecutionContext, PartitionedQueryExecutionContextInfo } from ".";
import { ClientContext } from "../ClientContext";
import { Response } from "../request/request";
/** @hidden */
export declare enum ParallelQueryExecutionContextBaseStates {
    started = "started",
    inProgress = "inProgress",
    ended = "ended"
}
/** @hidden */
export declare abstract class ParallelQueryExecutionContextBase implements IExecutionContext {
    private clientContext;
    private collectionLink;
    private query;
    private options;
    private partitionedQueryExecutionInfo;
    private static readonly DEFAULT_PAGE_SIZE;
    private err;
    private state;
    private static STATES;
    private routingProvider;
    protected sortOrders: any;
    private pageSize;
    private requestContinuation;
    private respHeaders;
    private orderByPQ;
    private sem;
    private waitingForInternalExecutionContexts;
    /**
     * Provides the ParallelQueryExecutionContextBase.
     * This is the base class that ParallelQueryExecutionContext and OrderByQueryExecutionContext will derive from.
     *
     * When handling a parallelized query, it instantiates one instance of
     * DocumentProcuder per target partition key range and aggregates the result of each.
     *
     * @constructor ParallelQueryExecutionContext
     * @param {ClientContext} clientContext        - The service endpoint to use to create the client.
     * @param {string} collectionLink                - The Collection Link
     * @param {FeedOptions} [options]                - Represents the feed options.
     * @param {object} partitionedQueryExecutionInfo - PartitionedQueryExecutionInfo
     * @ignore
     */
    constructor(clientContext: ClientContext, collectionLink: string, query: any, // TODO: any - It's not SQLQuerySpec
    options: any, partitionedQueryExecutionInfo: PartitionedQueryExecutionContextInfo);
    protected abstract documentProducerComparator(dp1: DocumentProducer, dp2: DocumentProducer): number;
    getPartitionKeyRangesForContinuation(suppliedCompositeContinuationToken: any, partitionKeyRanges: any): any;
    private _decrementInitiationLock;
    private _mergeWithActiveResponseHeaders;
    private _getAndResetActiveResponseHeaders;
    private _onTargetPartitionRanges;
    /**
     * Gets the replacement ranges for a partitionkeyrange that has been split
     * @memberof ParallelQueryExecutionContextBase
     * @instance
     */
    private _getReplacementPartitionKeyRanges;
    /**
     * Removes the current document producer from the priqueue,
     * replaces that document producer with child document producers,
     * then reexecutes the originFunction with the corrrected executionContext
     * @memberof ParallelQueryExecutionContextBase
     * @instance
     */
    private _repairExecutionContext;
    private static _needPartitionKeyRangeCacheRefresh;
    /**
     * Checks to see if the executionContext needs to be repaired.
     * if so it repairs the execution context and executes the ifCallback,
     * else it continues with the current execution context and executes the elseCallback
     * @memberof ParallelQueryExecutionContextBase
     * @instance
     */
    private _repairExecutionContextIfNeeded;
    /**
     * Execute a provided function on the next element in the ParallelQueryExecutionContextBase.
     * @memberof ParallelQueryExecutionContextBase
     * @instance
     * @param {callback} callback - Function to execute for each element. the function takes two \
     * parameters error, element.
     */
    nextItem(): Promise<Response<any>>;
    /**
     * Retrieve the current element on the ParallelQueryExecutionContextBase.
     * @memberof ParallelQueryExecutionContextBase
     * @instance
     * @param {callback} callback - Function to execute for the current element. \
     * the function takes two parameters error, element.
     */
    current(): Promise<Response<any>>;
    /**
     * Determine if there are still remaining resources to processs based on the value of the continuation \
     * token or the elements remaining on the current batch in the QueryIterator.
     * @memberof ParallelQueryExecutionContextBase
     * @instance
     * @returns {Boolean} true if there is other elements to process in the ParallelQueryExecutionContextBase.
     */
    hasMoreResults(): boolean;
    /**
     * Creates document producers
     */
    private _createTargetPartitionQueryExecutionContext;
}
