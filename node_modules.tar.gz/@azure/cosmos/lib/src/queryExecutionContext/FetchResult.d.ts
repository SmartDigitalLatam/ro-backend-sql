/** @hidden */
export declare enum FetchResultType {
    "Done" = 0,
    "Exception" = 1,
    "Result" = 2
}
/** @hidden */
export declare class FetchResult {
    feedResponse: any;
    fetchResultType: FetchResultType;
    error: any;
    /**
     * Wraps fetch results for the document producer.
     * This allows the document producer to buffer exceptions so that actual results don't get flushed during splits.
     * @constructor DocumentProducer
     * @param {object} feedReponse                  - The response the document producer got back on a successful fetch
     * @param {object} error                        - The exception meant to be buffered on an unsuccessful fetch
     * @ignore
     */
    constructor(feedResponse: any, error: any);
}
