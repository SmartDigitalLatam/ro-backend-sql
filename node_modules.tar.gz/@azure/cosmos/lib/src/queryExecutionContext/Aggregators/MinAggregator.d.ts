import { IAggregator } from "./IAggregator";
/** @hidden */
export declare class MinAggregator implements IAggregator<number> {
    private value;
    private comparer;
    /**
     * Represents an aggregator for MIN operator.
     * @constructor MinAggregator
     * @ignore
     */
    constructor();
    /**
     * Add the provided item to aggregation result.
     * @memberof MinAggregator
     * @instance
     * @param other
     */
    aggregate(other: number): void;
    /**
     * Get the aggregation result.
     * @memberof MinAggregator
     * @instance
     */
    getResult(): number;
}
