import { IAggregator } from "./IAggregator";
/** @hidden */
export declare class CountAggregator implements IAggregator<number> {
    value: number;
    /**
     * Represents an aggregator for COUNT operator.
     * @constructor CountAggregator
     * @ignore
     */
    constructor();
    /**
     * Add the provided item to aggregation result.
     * @memberof CountAggregator
     * @instance
     * @param other
     */
    aggregate(other: number): void;
    /**
     * Get the aggregation result.
     * @memberof CountAggregator
     * @instance
     */
    getResult(): number;
}
