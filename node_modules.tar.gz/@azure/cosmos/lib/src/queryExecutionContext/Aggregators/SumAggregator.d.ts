import { IAggregator } from "./IAggregator";
/** @hidden */
export declare class SumAggregator implements IAggregator<number> {
    sum: number;
    /**
     * Add the provided item to aggregation result.
     * @memberof SumAggregator
     * @instance
     * @param other
     */
    aggregate(other: number): void;
    /**
     * Get the aggregation result.
     * @memberof SumAggregator
     * @instance
     */
    getResult(): number;
}
