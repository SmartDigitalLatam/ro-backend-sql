import { IAggregator } from "./IAggregator";
/** @hidden */
export interface IAverageAggregator {
    sum: number;
    count: number;
}
/** @hidden */
export declare class AverageAggregator implements IAverageAggregator, IAggregator<IAverageAggregator> {
    sum: number;
    count: number;
    /**
     * Add the provided item to aggregation result.
     * @memberof AverageAggregator
     * @instance
     * @param other
     */
    aggregate(other: IAverageAggregator): void;
    /**
     * Get the aggregation result.
     * @memberof AverageAggregator
     * @instance
     */
    getResult(): number;
}
