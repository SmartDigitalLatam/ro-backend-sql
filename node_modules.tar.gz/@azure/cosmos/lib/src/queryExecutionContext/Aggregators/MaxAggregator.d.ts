import { IAggregator } from "./IAggregator";
/** @hidden */
export declare class MaxAggregator implements IAggregator<number> {
    private value;
    private comparer;
    /**
     * Represents an aggregator for MAX operator.
     * @constructor MaxAggregator
     * @ignore
     */
    constructor();
    /**
     * Add the provided item to aggregation result.
     * @memberof MaxAggregator
     * @instance
     * @param other
     */
    aggregate(other: number): void;
    /**
     * Get the aggregation result.
     * @memberof MaxAggregator
     * @instance
     */
    getResult(): number;
}
