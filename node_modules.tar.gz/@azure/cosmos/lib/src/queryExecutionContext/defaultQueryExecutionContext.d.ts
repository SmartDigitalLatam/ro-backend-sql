import { IExecutionContext } from ".";
import { ClientContext } from "../ClientContext";
import { Response } from "../request";
import { SqlQuerySpec } from "./SqlQuerySpec";
/** @hidden */
export declare type FetchFunctionCallback = (options: any) => Promise<Response<any>>;
/** @hidden */
export declare class DefaultQueryExecutionContext implements IExecutionContext {
    private clientContext;
    private static readonly STATES;
    private query;
    private resources;
    private currentIndex;
    private currentPartitionIndex;
    private fetchFunctions;
    private options;
    continuation: any;
    private state;
    /**
     * Provides the basic Query Execution Context.
     * This wraps the internal logic query execution using provided fetch functions
     * @constructor DefaultQueryExecutionContext
     * @param {ClientContext} clientContext          - Is used to read the partitionKeyRanges for split proofing
     * @param {SqlQuerySpec | string} query          - A SQL query.
     * @param {FeedOptions} [options]                - Represents the feed options.
     * @param {callback | callback[]} fetchFunctions - A function to retrieve each page of data.
     *                          An array of functions may be used to query more than one partition.
     * @ignore
     */
    constructor(clientContext: ClientContext, query: string | SqlQuerySpec, options: any, fetchFunctions: FetchFunctionCallback | FetchFunctionCallback[]);
    /**
     * Execute a provided callback on the next element in the execution context.
     * @memberof DefaultQueryExecutionContext
     * @instance
     */
    nextItem(): Promise<Response<any>>;
    /**
     * Retrieve the current element on the execution context.
     * @memberof DefaultQueryExecutionContext
     * @instance
     */
    current(): Promise<Response<any>>;
    /**
     * Determine if there are still remaining resources to processs based on
     * the value of the continuation token or the elements remaining on the current batch in the execution context.
     * @memberof DefaultQueryExecutionContext
     * @instance
     * @returns {Boolean} true if there is other elements to process in the DefaultQueryExecutionContext.
     */
    hasMoreResults(): boolean;
    /**
     * Fetches the next batch of the feed and pass them as an array to a callback
     * @memberof DefaultQueryExecutionContext
     * @instance
     */
    fetchMore(): Promise<Response<any>>;
    private _canFetchMore;
}
