/** @hidden */
export declare class QueryRange {
    min: string;
    max: string;
    isMinInclusive: boolean;
    isMaxInclusive: boolean;
    /**
     * Represents a QueryRange.
     * @constructor QueryRange
     * @param {string} rangeMin                - min
     * @param {string} rangeMin                - max
     * @param {boolean} isMinInclusive         - isMinInclusive
     * @param {boolean} isMaxInclusive         - isMaxInclusive
     * @ignore
     */
    constructor(rangeMin: string, rangeMax: string, isMinInclusive: boolean, isMaxInclusive: boolean);
    overlaps(other: QueryRange): boolean;
    isEmpty(): boolean;
    /**
     * Parse a QueryRange from a partitionKeyRange
     * @returns QueryRange
     * @ignore
     */
    static parsePartitionKeyRange(partitionKeyRange: any): QueryRange;
    /**
     * Parse a QueryRange from a dictionary
     * @returns QueryRange
     * @ignore
     */
    static parseFromDict(queryRangeDict: any): QueryRange;
}
