import { Range } from "../range";
import { QueryRange } from "./QueryRange";
/** @hidden */
export declare class InMemoryCollectionRoutingMap {
    private rangeById;
    private rangeByInfo;
    private orderedPartitionKeyRanges;
    private orderedRanges;
    orderedPartitionInfo: any;
    private collectionUniqueId;
    /**
     * Represents a InMemoryCollectionRoutingMap Object,
     * Stores partition key ranges in an efficient way with some additional information and provides
     * convenience methods for working with set of ranges.
     */
    constructor(rangeById: Range[], rangeByInfo: string, orderedPartitionKeyRanges: any[], orderedPartitionInfo: any, collectionUniqueId: string);
    getOrderedParitionKeyRanges(): any[];
    getRangeByEffectivePartitionKey(effectivePartitionKeyValue: string): any;
    private static _vbCompareFunction;
    getOverlappingRanges(providedQueryRanges: QueryRange | QueryRange[]): any[];
}
