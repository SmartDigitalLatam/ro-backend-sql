import { InMemoryCollectionRoutingMap, QueryRange } from ".";
import { ClientContext } from "../ClientContext";
/** @hidden */
export declare class PartitionKeyRangeCache {
    private clientContext;
    private collectionRoutingMapByCollectionId;
    private sem;
    constructor(clientContext: ClientContext);
    /**
     * Finds or Instantiates the requested Collection Routing Map and invokes callback
     * @param {callback} callback                - Function to execute for the collection routing map.
     *                                             the function takes two parameters error, collectionRoutingMap.
     * @param {string} collectionLink            - Requested collectionLink
     * @ignore
     */
    onCollectionRoutingMap(collectionLink: string): Promise<InMemoryCollectionRoutingMap>;
    /**
     * Given the query ranges and a collection, invokes the callback on the list of overlapping partition key ranges
     * @param {callback} callback - Function execute on the overlapping partition key ranges result,
     *                                  takes two parameters error, partition key ranges
     * @param collectionLink
     * @param queryRanges
     * @ignore
     */
    getOverlappingRanges(collectionLink: string, queryRanges: QueryRange): Promise<any[]>;
}
