import { QueryRange } from ".";
import { ClientContext } from "../ClientContext";
/** @hidden */
export declare const PARITIONKEYRANGE: {
    MinInclusive: string;
    MaxExclusive: string;
    Id: string;
};
/** @hidden */
export declare class SmartRoutingMapProvider {
    private partitionKeyRangeCache;
    constructor(clientContext: ClientContext);
    private static _secondRangeIsAfterFirstRange;
    private static _isSortedAndNonOverlapping;
    private static _stringMax;
    private static _stringCompare;
    private static _subtractRange;
    /**
     * Given the sorted ranges and a collection, invokes the callback on the list of overlapping partition key ranges
     * @param {callback} callback - Function execute on the overlapping partition key ranges result,
     *                              takes two parameters error, partition key ranges
     * @param collectionLink
     * @param sortedRanges
     * @ignore
     */
    getOverlappingRanges(collectionLink: string, sortedRanges: QueryRange[]): Promise<any[]>;
}
