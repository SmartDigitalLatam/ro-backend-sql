import { CosmosClientOptions, IHeaders, QueryIterator, RequestOptions, Response, SqlQuerySpec } from ".";
import { PartitionKeyRange } from "./client/Container/PartitionKeyRange";
import { Resource } from "./client/Resource";
import { DatabaseAccount } from "./documents";
import { GlobalEndpointManager } from "./globalEndpointManager";
import { FeedOptions } from "./request";
/**
 * @hidden
 * @ignore
 */
export declare class ClientContext {
    private cosmosClientOptions;
    private globalEndpointManager;
    private readonly sessionContainer;
    private connectionPolicy;
    private requestHandler;
    partitionKeyDefinitionCache: {
        [containerUrl: string]: any;
    };
    constructor(cosmosClientOptions: CosmosClientOptions, globalEndpointManager: GlobalEndpointManager);
    /** @ignore */
    read<T>(path: string, type: string, id: string, initialHeaders: IHeaders, options?: RequestOptions): Promise<Response<T & Resource>>;
    queryFeed<T>(path: string, type: string, // TODO: code smell: enum?
    id: string, resultFn: (result: {
        [key: string]: any;
    }) => any[], // TODO: any
    query: SqlQuerySpec | string, options: FeedOptions, partitionKeyRangeId?: string): Promise<Response<T & Resource>>;
    queryPartitionKeyRanges(collectionLink: string, query?: string | SqlQuerySpec, options?: FeedOptions): QueryIterator<PartitionKeyRange>;
    delete<T>(path: string, type: string, id: string, initialHeaders: IHeaders, options?: RequestOptions): Promise<Response<T & Resource>>;
    create<T>(body: T, path: string, type: string, id: string, initialHeaders: IHeaders, options?: RequestOptions): Promise<Response<T & Resource>>;
    create<T, U>(body: T, path: string, type: string, id: string, initialHeaders: IHeaders, options?: RequestOptions): Promise<Response<T & U & Resource>>;
    private processQueryFeedResponse;
    private applySessionToken;
    replace<T>(resource: any, path: string, type: string, id: string, initialHeaders: IHeaders, options?: RequestOptions): Promise<Response<T & Resource>>;
    upsert<T>(body: T, path: string, type: string, id: string, initialHeaders: IHeaders, options?: RequestOptions): Promise<Response<T & Resource>>;
    upsert<T, U>(body: T, path: string, type: string, id: string, initialHeaders: IHeaders, options?: RequestOptions): Promise<Response<T & U & Resource>>;
    execute<T>(sprocLink: string, params?: any[], // TODO: any
    options?: RequestOptions): Promise<Response<T>>;
    /**
     * Gets the Database account information.
     * @param {string} [options.urlConnection]   - The endpoint url whose database account needs to be retrieved. \
     * If not present, current client's url will be used.
     */
    getDatabaseAccount(options?: RequestOptions): Promise<Response<DatabaseAccount>>;
    getWriteEndpoint(): Promise<string>;
    getReadEndpoint(): Promise<string>;
    private captureSessionToken;
    private getSessionToken;
    clearSessionToken(path: string): void;
    private getSessionParams;
    private isMasterResource;
}
