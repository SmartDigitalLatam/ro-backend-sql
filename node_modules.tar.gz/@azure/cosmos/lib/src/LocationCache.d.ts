import { CosmosClientOptions } from "./CosmosClientOptions";
import { DatabaseAccount } from "./documents";
import { RequestContext } from "./request/RequestContext";
/**
 * Implements the abstraction to resolve target location for geo-replicated Database Account
 * with multiple writable and readable locations.
 * @private
 * @hidden
 */
export declare class LocationCache {
    private options;
    private locationUnavailabilityInfoByEndpoint;
    private locationInfo;
    private lastCacheUpdateTimestamp;
    private defaultEndpoint;
    private enableMultipleWritableLocations;
    constructor(options: CosmosClientOptions);
    readonly prefferredLocations: string[];
    getWriteEndpoint(): string;
    getReadEndpoint(): string;
    /**
     * Gets list of write endpoints ordered by
     * 1. Preferred location
     * 2. Endpoint availability
     */
    getWriteEndpoints(): ReadonlyArray<string>;
    /**
     * Gets list of read endpoints ordered by
     * 1. Preferred location
     * 2. Endpoint availability
     */
    getReadEndpoints(): ReadonlyArray<string>;
    markCurrentLocationUnavailableForRead(endpoint: string): void;
    markCurrentLocationUnavailableForWrite(endpoint: string): void;
    /**
     * Invoked when {@link DatabaseAccount} is read
     * @param databaseAccount The DatabaseAccount read
     */
    onDatabaseAccountRead(databaseAccount: DatabaseAccount): void;
    resolveServiceEndpoint(request: RequestContext): string;
    shouldRefreshEndpoints(): {
        shouldRefresh: boolean;
        canRefreshInBackground: boolean;
    };
    canUseMultipleWriteLocations(request?: RequestContext): boolean;
    private clearStaleEndpointUnavailabilityInfo;
    private isEndpointUnavailable;
    private markEndpointUnavailable;
    private updateLocationCache;
    private getPreferredAvailableEndpoints;
    private getEndpointByLocation;
    private canUpdateCache;
    private static normalizeLocationName;
}
