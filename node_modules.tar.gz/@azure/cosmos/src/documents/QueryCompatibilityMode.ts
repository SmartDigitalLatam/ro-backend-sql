// TODO: Should we remove this?
export enum QueryCompatibilityMode {
  Default = 0,
  Query = 1,
  SqlQuery = 2
}
