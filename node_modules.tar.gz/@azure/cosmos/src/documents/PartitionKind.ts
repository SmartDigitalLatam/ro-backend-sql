export enum PartitionKind {
  Hash = "Hash"
}
